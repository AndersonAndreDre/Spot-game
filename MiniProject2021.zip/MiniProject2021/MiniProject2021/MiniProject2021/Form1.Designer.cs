﻿
namespace MiniProject2021
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chkExperience = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radSports = new System.Windows.Forms.RadioButton();
            this.radSimulation = new System.Windows.Forms.RadioButton();
            this.radAction = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.lblPaymentDue = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblAveScore = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblAllAverage = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblNumValReviewers = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(106, 314);
            this.btnProcess.Margin = new System.Windows.Forms.Padding(2);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(95, 27);
            this.btnProcess.TabIndex = 0;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(293, 314);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(95, 27);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(480, 314);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 27);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 68);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Phone number";
            // 
            // chkExperience
            // 
            this.chkExperience.AutoSize = true;
            this.chkExperience.Location = new System.Drawing.Point(103, 128);
            this.chkExperience.Margin = new System.Windows.Forms.Padding(2);
            this.chkExperience.Name = "chkExperience";
            this.chkExperience.Size = new System.Drawing.Size(95, 19);
            this.chkExperience.TabIndex = 5;
            this.chkExperience.Text = "Experienced?";
            this.chkExperience.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(302, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 28);
            this.label2.TabIndex = 6;
            this.label2.Text = "SPOT ON!";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radSports);
            this.groupBox1.Controls.Add(this.radSimulation);
            this.groupBox1.Controls.Add(this.radAction);
            this.groupBox1.Location = new System.Drawing.Point(442, 57);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(132, 104);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Genre";
            this.toolTip2.SetToolTip(this.groupBox1, "Select game genre");
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // radSports
            // 
            this.radSports.AutoSize = true;
            this.radSports.Location = new System.Drawing.Point(18, 70);
            this.radSports.Margin = new System.Windows.Forms.Padding(2);
            this.radSports.Name = "radSports";
            this.radSports.Size = new System.Drawing.Size(58, 19);
            this.radSports.TabIndex = 2;
            this.radSports.TabStop = true;
            this.radSports.Text = "Sports";
            this.radSports.UseVisualStyleBackColor = true;
            // 
            // radSimulation
            // 
            this.radSimulation.AutoSize = true;
            this.radSimulation.Location = new System.Drawing.Point(18, 49);
            this.radSimulation.Margin = new System.Windows.Forms.Padding(2);
            this.radSimulation.Name = "radSimulation";
            this.radSimulation.Size = new System.Drawing.Size(82, 19);
            this.radSimulation.TabIndex = 1;
            this.radSimulation.TabStop = true;
            this.radSimulation.Text = "Simulation";
            this.radSimulation.UseVisualStyleBackColor = true;
            // 
            // radAction
            // 
            this.radAction.AutoSize = true;
            this.radAction.Location = new System.Drawing.Point(18, 28);
            this.radAction.Margin = new System.Windows.Forms.Padding(2);
            this.radAction.Name = "radAction";
            this.radAction.Size = new System.Drawing.Size(60, 19);
            this.radAction.TabIndex = 0;
            this.radAction.TabStop = true;
            this.radAction.Text = "Action";
            this.radAction.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 196);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Payment due to reviewer";
            // 
            // lblPaymentDue
            // 
            this.lblPaymentDue.AutoSize = true;
            this.lblPaymentDue.Location = new System.Drawing.Point(246, 196);
            this.lblPaymentDue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPaymentDue.Name = "lblPaymentDue";
            this.lblPaymentDue.Size = new System.Drawing.Size(28, 15);
            this.lblPaymentDue.TabIndex = 9;
            this.lblPaymentDue.Text = "0.00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(389, 196);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Average score for reviewer";
            // 
            // lblAveScore
            // 
            this.lblAveScore.AutoSize = true;
            this.lblAveScore.Location = new System.Drawing.Point(598, 196);
            this.lblAveScore.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAveScore.Name = "lblAveScore";
            this.lblAveScore.Size = new System.Drawing.Size(13, 15);
            this.lblAveScore.TabIndex = 11;
            this.lblAveScore.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(56, 269);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Average score for all reviewers";
            // 
            // lblAllAverage
            // 
            this.lblAllAverage.AutoSize = true;
            this.lblAllAverage.Location = new System.Drawing.Point(263, 269);
            this.lblAllAverage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAllAverage.Name = "lblAllAverage";
            this.lblAllAverage.Size = new System.Drawing.Size(13, 15);
            this.lblAllAverage.TabIndex = 13;
            this.lblAllAverage.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(389, 269);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "Number of valid reviewers";
            // 
            // lblNumValReviewers
            // 
            this.lblNumValReviewers.AutoSize = true;
            this.lblNumValReviewers.Location = new System.Drawing.Point(598, 269);
            this.lblNumValReviewers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumValReviewers.Name = "lblNumValReviewers";
            this.lblNumValReviewers.Size = new System.Drawing.Size(13, 15);
            this.lblNumValReviewers.TabIndex = 15;
            this.lblNumValReviewers.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(184, 232);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(267, 15);
            this.label11.TabIndex = 16;
            this.label11.Text = "****************************************************";
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Location = new System.Drawing.Point(246, 65);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(100, 23);
            this.txtPhoneNo.TabIndex = 17;
            // 
            // toolTip2
            // 
            this.toolTip2.IsBalloon = true;
            this.toolTip2.ShowAlways = true;
            this.toolTip2.ToolTipTitle = "ONLY ONE GENRE CAN BE SELECTED";
            this.toolTip2.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip2_Popup);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 371);
            this.Controls.Add(this.txtPhoneNo);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblNumValReviewers);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblAllAverage);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblAveScore);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblPaymentDue);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.chkExperience);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnProcess);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mini project 2021";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkExperience;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radSports;
        private System.Windows.Forms.RadioButton radSimulation;
        private System.Windows.Forms.RadioButton radAction;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblPaymentDue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAllAverage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblNumValReviewers;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label lblAveScore;
        private System.Windows.Forms.Label lblNumReviewers;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.ToolTip toolTip2;
    }
}

