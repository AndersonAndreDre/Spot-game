﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// type your student number(s) here
//2308854 AND 2392982

namespace MiniProject2021
{
    public partial class Form1 : Form
    {
        //CONSTANTS
        const double dblGamePrice = 200;
        const double dblBonusDiscRate = 0.05;


        //VARIABLES
        int intNumValReviewer = 0;
        double dblAllAverage = 0;
        
        double dblAveScore = 0;
        double dblPaymentDue = 0;
        


        public Form1()
        {

            InitializeComponent();
            

        }
       
        
        public static string InputBox(string prompt, string title, string defaultValue)
        {
            InputBoxDialog ib = new InputBoxDialog();
            ib.FormPrompt = prompt;
            ib.FormCaption = title;
            ib.DefaultValue = defaultValue;
            ib.ShowDialog();
            string s = ib.InputResponse;
            ib.Close();
            return s;
        }




        private void btnProcess_Click(object sender, EventArgs e)
        {
         
            // this is the mainline of the program

            
            
            //ASSIGN LOCAL VARIBLES

            double dblAccumScore = 0;
            
            double dblNoOfGame = 0;
          
            double dblGameScore = 0;
            
            bool blnValidInput = true;
            bool blnValidGameCode = true;
            bool blnValidGameScore = true;
            
            blnValidInput = ValidateFormInput(blnValidInput);
            //GETIING THE INPUT
            
            
            string GameCode = InputBox("Enter GAME CODE", "GAME CODE", "");
            
            //XXXX in caps to terminate
            while (GameCode != "XXXX")
            {
                dblNoOfGame += 1;




                blnValidGameCode = ValidateGameCode(blnValidGameCode, GameCode);

            
                dblGameScore = Convert.ToDouble(InputBox("Enter Game Score ", "GAMESCORE", ""));
               
                
                blnValidGameScore = ValidateScore(blnValidGameScore, dblGameScore);
                
                GameCode = InputBox("Enter GAME CODE", "GAME CODE", "");
               



                dblAccumScore += dblGameScore;
                










            }
            //ALL INPUT MUST BE VALID AND THERE MUST BE ATLEAT ON GAME
            if (blnValidInput==true && blnValidGameCode==true && blnValidGameScore == true){
                if(dblNoOfGame!=0)
                {
                    intNumValReviewer += 1;


                }

            }


           //METHODS
            AveScore(dblAccumScore, dblNoOfGame);
            AllAverage();
            CalcAmtDue(dblBonusDiscRate, dblNoOfGame);
            //THIS FOR INCASE A USER JUST TYPE GAMECODE AS XXXX AT THE BEGINING
            if (dblNoOfGame > 0)
            {

                DisplayOutputs();


            }





        }




        public void DisplayOutputs()
        {




            //For EACH REVIEWER
            lblPaymentDue.Text = "R"+dblPaymentDue.ToString("F2");

           lblAveScore.Text = dblAveScore.ToString("F2");
            

            //FOR ALL REVIEWERS
            lblAllAverage.Text = dblAllAverage.ToString("F2");
            lblNumValReviewers.Text = intNumValReviewer.ToString("");

        }

        public double CalcAmtDue(double dblBonusDiscRate, double dblNumOfGames)
        {

            dblPaymentDue = dblGamePrice * dblNumOfGames;
            
           if (chkExperience.Checked == true)
            { 

                if (dblNumOfGames > 2)
                {
                    dblPaymentDue -= (dblPaymentDue * dblBonusDiscRate);
                }
            
            }
           
            
            return dblPaymentDue;
        }
        public double AveScore(double dblAccumScore , double dblNumOfGames)
        {
            //THIS METHOD CALCULATE THE AVERAGE SCORE FOR EACH REVIEWER

           dblAveScore = dblAccumScore / dblNumOfGames;
           
            return dblAveScore;

        }
        public  double AllAverage()
        {
            //THIS METHOD CALCULATE THE AVERAGE SCORE FOR ALL THE REVIEWERS
            dblAllAverage += dblAveScore;
            return dblAllAverage;
        }
      
        
        private bool ValidateFormInput(bool blnValidFormInput)
        {
            // this method validates the form input
            // the masked text box (or text box) for the phone number must be completely entered (or entered)
            // the genre must be chosen

            {
                if (txtPhoneNo.TextLength != 10)  //PHONE NUMBER MUST BE ENTERED AND BE TEN DIGITS
                {
                    blnValidFormInput = false;
                    MessageBox.Show("invalid phone number", "PHONE NUMBER ERROR");

                }

            }
            if (radAction.Checked == false && radSimulation.Checked == false && radSports.Checked == false)
            {
                blnValidFormInput = false;
                MessageBox.Show("please chose genre", "GENRE ERROR");
            }
            return blnValidFormInput;
        }


        private bool ValidateScore(bool blnValidScore, double dblGameScore)
        {
            //  this method validates the score the reviewer has given a game

            if (dblGameScore < 1 || dblGameScore > 5)
            {
                blnValidScore = false;
                MessageBox.Show("invalid score", "SCORE ERROR");
            }
            return blnValidScore;
        }


      
        private bool ValidateGameCode(bool blnValidGameCode, string GameCode)
        {
           //THIS METHOD VALIDATE THE GAMECODES 
            if (radAction.Checked == true)
            {
                if (GameCode != "ACT123" )
                {
                    if (GameCode != "ACT456" )
                    {
                        if (GameCode != "ACT789" )
                        {
                            if (GameCode != "XXXX")
                            {
                                blnValidGameCode = false;
                                MessageBox.Show("invalid game code", "GAMECODE ERROR");
                            }
                        }
                    }
                }

            }

            if (radSimulation.Checked == true)
            {
                if (GameCode != "SIM111")
                {
                    if (GameCode != "SIM222")
                    {
                        if (GameCode != "SIM333")
                        {
                            if (GameCode != "XXXX") {
                                blnValidGameCode = false;
                                MessageBox.Show("invalid game code", "GAMECODE ERROR");
                            }
                        }
                    }
                }
            }

            if (radSports.Checked == true)
            {
                if (GameCode != "SPT001" )
                {
                    if (GameCode != "SPT002" )
                    {
                        if (GameCode != "SPT003" )
                        {
                            if (GameCode != "XXXX")
                            {
                                blnValidGameCode = false;

                                MessageBox.Show("invalid game code", "GAMECODE ERROR");
                            }
                        }
                    }
                }
            }
         
            return blnValidGameCode;
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            // this method clears the form, except for the accumulated totals
            // focus is placed at the phone number

            chkExperience.Checked = false;
            radAction.Checked = false;
            radSimulation.Checked = false;
            radSports.Checked = false;
            lblPaymentDue.Text = "0.00";
            lblAveScore.Text = "0";
            txtPhoneNo.Text = "";
            txtPhoneNo.Focus();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // this method closes the program

            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolTip2_Popup(object sender, PopupEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }

}
